# recomendador_v2
Recomendador de acciones de mantenimiento v2.0. Mejora: recomendar un pull de acciones para cada equipo.
